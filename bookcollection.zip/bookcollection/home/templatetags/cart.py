from django import template

register = template.Library()

@register.filter(name='carted')
def carted(cart):
    if cart:
            return True
    return False

@register.filter(name='is_in_cart')
def is_in_cart(i, cart):
    keys = cart.keys()
    print(keys)
    for id in keys:
        if int(id) == i.id:
            return True
    return False

@register.filter(name='cart_quantity')
def cart_quantity(i, cart):
    keys = cart.keys()
    for id in keys:
        if int(id) == i.id:
            return cart.get(id)
    return 0;

