from django.shortcuts import render
from django.contrib.auth.hashers import make_password, check_password
from django.shortcuts import redirect
from .models.model import Product
from .models.category import Categorie
from .models.customer import Customer
from django.views import View



class Index(View):
    def get(self,request):
        products = None
        categories = Categorie.get_all_category()
        categoryID = request.GET.get('category')
        print("you are : ", request.session.get('customer'))
        name = request.session.get('name')
        print(name, "dsfdsf")
        user = {
            'name': name,
        }
        if categoryID:
            products = Product.get_all_products_by_categoryid(categoryID)
        else:
            products = Product.get_all_products()
        data = {}
        data['products'] = products
        data['categories'] = categories
        data['user'] = user
        return render(request, 'home.html', data)

    def POST(self, request):
        return render(request, 'search.html')

class Category(View):
    def post(self, request):
        product = request.POST.get('product')
        cart = request.session.get('cart')
        remove = request.POST.get('remove')
        if cart:
            quantity = cart.get(product)
            if quantity:
                if remove:
                    if quantity <= 1:
                        cart.pop(product)
                    else:
                        cart[product] = quantity - 1
                else:
                    cart[product] = quantity+1
            else:
                cart[product] = 1
        else:
            cart = {}
            cart[product] = 1
        request.session['cart'] = cart
        print('cart : ', cart)
        return redirect('categories')


    def get(self, request):
        cart = request.session.get('cart')
        if not cart:
            request.session['cart'] = {}
        products = None
        categories = Categorie.get_all_category()
        categoryID = request.GET.get('category')
        if categoryID:
            products = Product.get_all_products_by_categoryid(categoryID)
        else:
            products = Product.get_all_products()
        data = {}
        data['products'] = products
        data['categories'] = categories
        return render(request, 'categories.html', data)

class Signup(View):
    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        first_name = request.POST.get('firstname')
        last_name = request.POST.get('lastname')
        password = request.POST.get('password')
        mobile_number = request.POST.get('mobilenumber')
        email = request.POST.get('email')
        # validation
        value = {
            'first_name': first_name,
            'last_name': last_name,
            'mobile_number': mobile_number,
            'email': email
        }

        customer = Customer(first_name=first_name,
                            last_name=last_name,
                            password=password,
                            mobile_number=mobile_number,
                            email=email)

        error_message = None

        if len(first_name) < 4:
            error_message = "First Name must 4 character long or more !! "

        elif len(last_name) < 4:
            error_message = "Last Name must 4 character long or more !! "

        elif len(mobile_number) < 10:
            error_message = "Mobile No. must be valid !! "

        elif customer.isExists():
            error_message = "This Email Address is already registered !! "

        if not (error_message):
            customer.password = make_password(customer.password)
            customer.save()
            return redirect('login')

        else:
            data = {
                'error': error_message,
                'values': value
            }

            return render(request, 'signup.html', data)

class Login(View):
    def get(self, request):
        return render(request, 'login.html')

    def post(self, request):
        email = request.POST.get('email')
        password = request.POST.get('password')
        customer = Customer.get_customer_by_email(email)
        error_message = None
        if customer:
            flag = check_password(password, customer.password)
            if flag:
                request.session['customer'] = customer.id
                request.session['name'] = customer.first_name
                return redirect('homepage')
            else:
                error_message = "Email or Password invalid !! "
        else:
            error_message = "Email or Password invalid !! "
        return render(request, 'login.html', {'error': error_message})

def logout(request):
    request.session.clear()
    return redirect('login')

class Cart(View):
    def get(self, request):
        ids = list(request.session.get('cart').keys())
        print("sddsdssdsds",ids)
        products = Product.get_all_products_by_id(ids)
        return render(request, 'cart.html', {'products': products})